﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    class EveningTime
    {
        public static void EveningTimeMod()
        {
            BetterDayNightManager.instance.SetTimeOfDay(7);
        }
    }
}
