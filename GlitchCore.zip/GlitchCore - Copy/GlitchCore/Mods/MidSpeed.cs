﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    class MidSpeed
    {
        public static void SmallSpeedMod()
        {
            GorillaLocomotion.Player.Instance.jumpMultiplier = 9f;
            GorillaLocomotion.Player.Instance.maxJumpSpeed = 9f;
        }
    }
}
