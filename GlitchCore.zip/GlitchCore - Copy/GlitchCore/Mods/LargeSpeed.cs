﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    class LargeSpeed
    {
        public static void SmallSpeedMod()
        {
            GorillaLocomotion.Player.Instance.jumpMultiplier = 12f;
            GorillaLocomotion.Player.Instance.maxJumpSpeed = 12f;
        }
    }
}
