﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    class LongArms
    {
        public static void LongArmsmod()
        {
            GorillaLocomotion.Player.Instance.maxArmLength = 9f;
        }
    }
}