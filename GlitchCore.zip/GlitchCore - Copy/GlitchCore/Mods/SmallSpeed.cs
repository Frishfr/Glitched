﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    class SmallSpeed
    {
        public static void SmallSpeedMod()
        {
            GorillaLocomotion.Player.Instance.jumpMultiplier = 5f;
            GorillaLocomotion.Player.Instance.maxJumpSpeed = 5f;
        }
    }
}
