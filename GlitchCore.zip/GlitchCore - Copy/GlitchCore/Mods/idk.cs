﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine.Device;

namespace StupidTemplate.Mods
{
    class idk
    {
        
    }
}
