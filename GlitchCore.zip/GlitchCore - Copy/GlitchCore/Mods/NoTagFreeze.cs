﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    class NoTagFreeze
    {
        public static void NoTagFreezeMod()
        {
            GorillaLocomotion.Player.Instance.disableMovement = false;
        }
    }
}
