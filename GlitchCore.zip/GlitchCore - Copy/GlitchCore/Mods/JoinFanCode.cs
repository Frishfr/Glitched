﻿using GorillaNetworking;
using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    class JoinFanCode
    {
        public static void JoinGhostCode()
        {
            var ghostCodes = new List<(string code, int length)>
            {
                ("GLITCHED", 4)
            };

            var random = new System.Random();
            var randomGhostCode = ghostCodes[random.Next(ghostCodes.Count)];

            string roomName = $"{randomGhostCode.code}.{randomGhostCode.length}";

            PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(roomName, (JoinType)6);
        }
    }
}
