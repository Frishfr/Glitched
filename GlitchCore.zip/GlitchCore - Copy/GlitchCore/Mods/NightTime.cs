﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    class NightTime
    {
        public static void NightTimeMod()
        {
            BetterDayNightManager.instance.SetTimeOfDay(0);
        }
    }
}
