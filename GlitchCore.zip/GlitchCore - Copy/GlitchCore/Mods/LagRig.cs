﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    class LagRig
    {
        public static void LagRigMod()
        {
            bool[] array44 = new bool[5];
            array44[0] = true;
            bool[] array45 = array44;
            int num76 = new System.Random().Next(array45.Length);
            bool flag435 = array45[num76];
            bool flag436 = flag435;
            if (flag436)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
            }
            bool[] array46 = new bool[5];
            array46[0] = true;
            bool[] array47 = array46;
            int num77 = new System.Random().Next(array47.Length);
            bool flag437 = array47[num77];
            bool flag438 = flag437;
            if (flag438)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
    }
}
