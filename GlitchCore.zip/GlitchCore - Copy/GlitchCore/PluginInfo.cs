﻿namespace StupidTemplate
{
    internal class PluginInfo
    {
        public const string GUID = "org.GLITCHED.gorillatag.GLITCHEDTEMPLATE";
        public const string Name = "GLITCHED V1";
        public const string Description = "Made By GLITCHED";
        public const string Version = "1.0.0";
    }
}
