﻿using StupidTemplate.Classes;
using StupidTemplate.Mods;
using static StupidTemplate.Settings;

namespace StupidTemplate.Menu
{
    internal class Buttons
    {
        public static ButtonInfo[][] buttons = new ButtonInfo[][]
        {
            new ButtonInfo[] { // Main Mods
                new ButtonInfo { buttonText = "AntiReport(Put On)", method =() => AntiReport.AntiReportMod(), isTogglable = true, toolTip = "when someone trys to report u you get kicked from lobby :]"},
                new ButtonInfo { buttonText = "JoinFanCode", method =() => JoinFanCode.JoinGhostCode(), isTogglable = true, toolTip = "Joins fan code GLITCHED :]"},
                new ButtonInfo { buttonText = "Settings", method =() => SettingsMods.EnterSettings(), isTogglable = false, toolTip = "Opens the main settings page for the menu."},
                new ButtonInfo { buttonText = "TrollMods", method =() => SettingsMods.TrollMods(), isTogglable = false, toolTip = "OPENS TROLL MODS :]"},
                new ButtonInfo { buttonText = "HideAndSeekMods", method =() => SettingsMods.HideAndSeekMods(), isTogglable = false, toolTip = "OPENS HIDE AND SEEK MODS :]"},
                new ButtonInfo { buttonText = "OPMods", method =() => SettingsMods.OPMods(), isTogglable = false, toolTip = "OPENS OP MODS :]"},
                new ButtonInfo { buttonText = "RigMods", method =() => SettingsMods.RigMods(), isTogglable = false, toolTip = "OPENS RIG MODS :]"},
                new ButtonInfo { buttonText = "YTMods", method =() => SettingsMods.YoutubeMods(), isTogglable = false, toolTip = "OPENS YOUTUBE MODS :]"},
                new ButtonInfo { buttonText = "BetaMods", method =() => SettingsMods.TestMods(), isTogglable = false, toolTip = "OPENS BETA MODS :]"},
            },

            new ButtonInfo[] { // Settings
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Returns to the main page of the menu."},
                new ButtonInfo { buttonText = "Menu", method =() => SettingsMods.MenuSettings(), isTogglable = false, toolTip = "Opens the settings for the menu."},
            },

            new ButtonInfo[] { // Menu Settings
                new ButtonInfo { buttonText = "Return to Settings", method =() => SettingsMods.EnterSettings(), isTogglable = false, toolTip = "Returns to the main settings page for the menu."},
                new ButtonInfo { buttonText = "Right Hand", enableMethod =() => SettingsMods.RightHand(), disableMethod =() => SettingsMods.LeftHand(), toolTip = "Puts the menu on your right hand."},
                new ButtonInfo { buttonText = "Notifications", enableMethod =() => SettingsMods.EnableNotifications(), disableMethod =() => SettingsMods.DisableNotifications(), enabled = !disableNotifications, toolTip = "Toggles the notifications."},
                new ButtonInfo { buttonText = "FPS Counter", enableMethod =() => SettingsMods.EnableFPSCounter(), disableMethod =() => SettingsMods.DisableFPSCounter(), enabled = fpsCounter, toolTip = "Toggles the FPS counter."},
                new ButtonInfo { buttonText = "Disconnect Button", enableMethod =() => SettingsMods.EnableDisconnectButton(), disableMethod =() => SettingsMods.DisableDisconnectButton(), enabled = disconnectButton, toolTip = "Toggles the disconnect button."},
            },

            new ButtonInfo[] { // Movement Settings
                new ButtonInfo { buttonText = "Return to Settings", method =() => SettingsMods.EnterSettings(), isTogglable = false, toolTip = "Returns to the main settings page for the menu."},
            },

            new ButtonInfo[] { // Projectile Settings
                new ButtonInfo { buttonText = "Return to Settings", method =() => SettingsMods.MenuSettings(), isTogglable = false, toolTip = "Opens the settings for the menu."},
            },

            new ButtonInfo[] { // TrollMods
                new ButtonInfo { buttonText = "Return to Main Page", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Goes Home"},
                new ButtonInfo { buttonText = "GhostMonke", method =() => GhostMonke.GhostMonkeMod(), isTogglable = true, toolTip = "hold A on controller :]"},
                new ButtonInfo { buttonText = "InvisMonke", method =() => InvisMonke.InvisMonkeMod(), isTogglable = true, toolTip = "press trigger :]"},
                new ButtonInfo { buttonText = "LongArms", method =() => LongArms.LongArmsmod(), isTogglable = true, toolTip = "makes arms long :]"},
                new ButtonInfo { buttonText = "NoTagFreeze", method =() => NoTagFreeze.NoTagFreezeMod(), isTogglable = true, toolTip = "no tag freeze (pretty self telling) :]"},
                new ButtonInfo { buttonText = "GrabDoug", method =() => GrabBug.GrabBugMod(), isTogglable = true, toolTip = "grabs doug :]"},
            },

            new ButtonInfo[] { // Hide And Seek Mods
                new ButtonInfo { buttonText = "Return to Main Page", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Goes Home"},
                new ButtonInfo { buttonText = "Tracer", method =() => Tracer.TracerMod(), isTogglable = true, toolTip = "tracer youll see!!! :]"},
                new ButtonInfo { buttonText = "TpToStump", method =() => TpToStump.TpToStumpMod(), isTogglable = true, toolTip = "TPS u to stump :]"},
            },

            new ButtonInfo[] { // OPMods
                new ButtonInfo { buttonText = "Return to Main Page", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "goes home"},
                new ButtonInfo { buttonText = "SmallSpeed", method =() => SmallSpeed.SmallSpeedMod(), isTogglable = true, toolTip = "small speed boost :]"},
                new ButtonInfo { buttonText = "MidSpeed", method =() => MidSpeed.SmallSpeedMod(), isTogglable = true, toolTip = "mid speed boost :]"},
                new ButtonInfo { buttonText = "largeSpeed", method =() => LargeSpeed.SmallSpeedMod(), isTogglable = true, toolTip = "large speed boost :]"},
                new ButtonInfo { buttonText = "WhitePlats", method =() => WhitePlats.WhitePlatsMod(), isTogglable = true, toolTip = "white platforms :]"},
                new ButtonInfo { buttonText = "GreenPlats", method =() => ClearPlats.ClearPlatsMod(), isTogglable = true, toolTip = "green plats platforms :]"},
            },

            new ButtonInfo[] { // RigMods
                new ButtonInfo { buttonText = "Return to Main Page", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "goes home"},
                new ButtonInfo { buttonText = "FixHead", method =() => FixHead.FixHeadMod(), isTogglable = true, toolTip = "Fix Head :]"},
                new ButtonInfo { buttonText = "SpazHead", method =() => SpazHead.SpazHeadMod(), isTogglable = true, toolTip = "spazes head :]"},
                new ButtonInfo { buttonText = "LagRig", method =() => LagRig.LagRigMod(), isTogglable = true, toolTip = "lags rig :]"},
                new ButtonInfo { buttonText = "GrabRig", method =() => GrabRig.GrabRigMod(), isTogglable = true, toolTip = "grabs ur rig :]"},
            },

            new ButtonInfo[] { // YoutubeMods
                new ButtonInfo { buttonText = "Return to Main Page", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "goes home"},
                new ButtonInfo { buttonText = "Rain", method =() => Rain.RainMod(), isTogglable = true, toolTip = "WHEN THERES RAIN THERES THUN- ok its just rain :]"},
                new ButtonInfo { buttonText = "StopRain", method =() => StopRain.StopRainMod(), isTogglable = true, toolTip = "stops the rain :]"},
                new ButtonInfo { buttonText = "DayTime", method =() => DayTime.DayTimeMod(), isTogglable = true, toolTip = "makes day time :]"},
                new ButtonInfo { buttonText = "EveningTime", method =() => EveningTime.EveningTimeMod(), isTogglable = true, toolTip = "makes evening time :]"},
                new ButtonInfo { buttonText = "NightTime", method =() => NightTime.NightTimeMod(), isTogglable = true, toolTip = "makes night time :]"},
            },

            new ButtonInfo[] { // TestMods
                new ButtonInfo { buttonText = "Return to Main Page", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "goes home"},
                new ButtonInfo { buttonText = "Sub", method =() => SettingsMods.OpenDiscordInvite(), isTogglable = true, toolTip = "idk :]"},
            },
        };
    }
}